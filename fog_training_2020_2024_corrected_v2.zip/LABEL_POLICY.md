# Fog truth policy v2

For EPIR historical training:

`fog_truth = explicit_fog_code OR (visibility_m < 1000 AND NOT precipitation)`

Explicit fog code means FG/FZFG/BCFG/PRFG.
Precipitation does not negate an explicit fog code; it only disables visibility-only inference.
AUTO reports with missing visibility are UNKNOWN, not CLEAR.
MIFG and BR remain separate states/targets.
