# Fog Engine offline training material — 2020–2024

Derived locally from the five uploaded archives. **Nothing in this directory was written to Supabase or GitHub.**

- Canonical METAR/SPECI: 67,770
- Historical SYNOP teacher records: 37,075
- Initial fog-family events: 485
- RMK precise-temperature records: 59,133
- RMK RH records: 59,121

`aviation_observations_2020_2024.jsonl` is the normalized operational-feature source.
`synop_teacher_2020_2024.jsonl` is historical-only teacher/context data.
`fog_events_2020_2024.csv` contains event segmentation, transitions and 6-hour pre-onset features.
`inventory_2020_2024.json` contains coverage and quality statistics.

The event mechanism is deliberately **not** hard-labelled from METAR alone. Radiation/advection/St→FG/precipitation mechanism labels should be assigned later by the hybrid mechanism classifier using these sequences plus NWP/satellite/radar context.
