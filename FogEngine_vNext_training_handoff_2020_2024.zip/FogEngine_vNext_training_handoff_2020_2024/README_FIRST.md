# Fog Engine vNext — paczka przekazania danych treningowych 2020–2024

## Status
Ta paczka NIE zawiera surowego archiwum obserwacji EPIR 2020–2024, ponieważ tych plików nie ma obecnie
ani w bibliotece ChatGPT, ani w repozytorium PrognozaEPIR/main.

Paczka zawiera:
- obowiązującą politykę etykiet,
- kontrakt danych dla nowego Fog Engine,
- schematy wymaganych plików,
- manifest oczekiwanych wejść,
- podsumowanie wcześniej przygotowanego zbioru 2020–2024,
- referencję do aktualnego `data/learning/fog-event-skill.json` z GitHuba,
- znaczniki brakujących plików.

## Co trzeba dołożyć przed treningiem
Do katalogu `REQUIRED_INPUTS/` należy wstawić rzeczywiste pliki:

1. `aviation_observations_2020_2024.jsonl`
2. `fog_events_2020_2024.csv`
3. `fog_events_censored_2020_2024.csv`
4. `label_policy_summary.json`
5. `inventory_2020_2024.json`
6. `synop_teacher_2020_2024.jsonl`

Jeżeli `label_policy_summary.json` nie zostanie dostarczony z poprzedniego pipeline'u,
można użyć wersji referencyjnej z `spec/label_policy_summary.json`.

## Zasada krytyczna
Nie wolno trenować modelu tak, jakby nocne obserwacje AUTO bez VIS oznaczały CLEAR.
Takie rekordy muszą pozostać UNKNOWN / missing.

## Truth-set
`fog_truth = true` gdy:
- jawny kod: FG, FZFG, BCFG lub PRFG,
- albo VIS < 1000 m i brak opadu.

BR i MIFG pozostają osobnymi stanami/targetami i nie są automatycznie zamieniane na FG.

## Cenzurowanie początku
Zdarzenia, których początek wypada przed pierwszą dostępną obserwacją danego epizodu,
muszą mieć `left_censored=true`. Takich przypadków nie wolno używać jako zwykłego dokładnego targetu
regresji czasu onsetu.

## Walidacja
Podział train/validation/test należy wykonywać po czasie / całych zdarzeniach, a nie losowo po rekordach,
aby nie dopuścić do leakage między sąsiednimi obserwacjami tego samego epizodu mgły.
