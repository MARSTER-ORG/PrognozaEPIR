# PrognozaEPIR — Fog Engine vNext: kontrakt treningowy

## Mechanizmy
Silnik zachowuje cztery główne mechanizmy:
- RAD — radiacyjny,
- ADV — adwekcyjny,
- CBL / Stratus→Fog,
- PCP — opadowy/frontowy.

BR i MIFG są osobnymi stanami/targetami, a nie mechanizmami.
Advection-radiation jest miękką kombinacją RAD+ADV.
Postfrontalność jest kontekstem/modulatorem.

## Niezależne rodziny cech procesowych
1. saturation / moisture state
2. radiative / surface cooling
3. mixing / stability / inversion / PBL
4. land moisture
5. cloud-base / stratus lowering
6. advection / moisture transport
7. precip / evaporative saturation

Nie sumować bezpośrednio wielu silnie skorelowanych wskaźników jako niezależnych głosów.

## Priorytetowe nowe cechy
- SSOIL: rzeczywista wilgotność gleby
  - ICON-D2 0–1 cm i 1–3 cm jako priorytet,
  - ECMWF jako drugie źródło,
  - precip-12h tylko fallback,
  - missing != 0.
- SPBL:
  - wysokość PBL,
  - bieżąca, -1 h, -3 h,
  - Δ1h i Δ3h.
- SSFC_COOL:
  - T2m − Tsurface,
  - trend temperatury powierzchni i near-surface.
- Soil temperature 0/6 cm:
  - diagnostycznie,
  - mała niezależna waga.
- T5cm_obs:
  - opcjonalnie dla nowcastu 0–3 h,
  - działanie silnika nie może od niego zależeć.

## Direct NWP guidance
Modelowa mgła / visibility / fog probability musi być oddzielnym kanałem od physics score,
aby ograniczyć double counting.

## Double counting
Wet-bulb nie może być niezależnym pełnym głosem Fog Score, jeśli równocześnie używane są T/Td/RH/spread.
FSI i fog-point tylko jako słabe/kalibrowane cechy pomocnicze.

## Faza mgły
Silnik ma rozróżniać:
- onset,
- fazę dojrzałą,
- dissipation.

Słabe mieszanie sprzyja onsetowi RAD, ale po utworzeniu mgły umiarkowana turbulencja może pogłębiać warstwę.
Dissipation engine powinien uwzględniać:
- insolację / surface warming,
- wzrost PBL,
- entrainment suchego powietrza,
- wiatr i shear,
- zmianę adwekcji,
- podnoszenie CBH.

## Heurystyki lokalne — tylko do kalibracji
- Tfog = Td − (Tmax−Td)/2
- Df = Tfog − Tmin
- wieczorny spread > ~7 K: silnie przeciw klasycznej mgle radiacyjnej
- słaby wiatr ~0.5–2 m/s: korzystny dla onsetu RAD
- ~4–5 m/s: kara dla RAD
- >~5 m/s: silna kara dla klasycznej RAD
- shear 0–300 m >~3 m/s/100 m: negatywny dla onsetu RAD

Nie implementować tych wartości jako uniwersalnych twardych progów.

## Adaptive model skill
DMI HARMONIE i KNMI mają pozostać w adaptiveWeights/fogEventSkill:
- zależność od lead time,
- minimalny floor,
- wygładzanie,
- odporność na pojedynczy błąd.

## Walidacja
Podział danych po czasie i po całych epizodach.
Zakaz random row split prowadzącego do leakage.
Raportować osobno:
- Brier score,
- reliability / calibration,
- ROC-AUC i PR-AUC,
- POD/recall dla fog_truth,
- FAR/precision,
- CSI,
- timing onset/dissipation tylko dla obserwacji niecenzurowanych.
