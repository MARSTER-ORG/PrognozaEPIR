# Podsumowanie poprzedniego przygotowania danych 2020–2024

Znane wartości z poprzedniego audytu:
- 67 770 obserwacji METAR/SPECI,
- 774 obserwacje z VIS < 1000 m bez opadu,
- 771 z nich miało już jawny kod mgły,
- 3 dodatkowe rekordy zostały przeklasyfikowane do `fog_truth=true`,
- łącznie `fog_truth=true`: 871 obserwacji,
- 485 zdarzeń BR/MIFG/FG,
- 129 zdarzeń zawierających mgłę,
- 88 z 129 zdarzeń z mgłą ma potencjalne lewostronne cenzurowanie.

Wniosek:
- dokładnego czasu onsetu nie wolno trenować na wszystkich 129 zdarzeniach jak na zwykłym targetcie,
- `VIS_FOG` nie powinno istnieć jako osobna klasa; przypadki VIS<1000 m bez opadu wchodzą do fog_truth,
- BR i MIFG pozostają osobnymi stanami.
